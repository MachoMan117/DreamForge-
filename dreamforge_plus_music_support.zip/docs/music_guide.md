# Music Integration in DreamForge+

## How to Add Music

1. Open the DreamForge+ app
2. Navigate to the Game Builder
3. Tap the 🎵 Music tab
4. Upload or assign audio files:
   - Background Music (BGM)
   - Sound Effects (SFX)

## Recommended File Types
- Music: `.mp3` or `.ogg` (small size, good quality)
- Sound Effects: `.wav` or `.ogg`

## Best Practices
- Looping: Use seamless loops for gameplay music
- Size: Keep files under 1MB if possible for mobile
- Naming: Use lowercase, underscore-separated names (e.g. `main_theme.mp3`)

## Engine Mapping
| Engine      | Supported? | Notes |
|-------------|------------|-------|
| Phaser      | ✅ Yes      | Uses `this.load.audio()` |
| Godot       | ✅ Yes      | Use `AudioStreamPlayer` nodes |
| Unity       | ✅ Yes      | Drag into `AudioSource` components |
| Love2D      | ✅ Yes      | Use `love.audio.newSource()` |

## Sample Template (Phaser)
```js
this.sound.add('jump_sfx').play();
```
