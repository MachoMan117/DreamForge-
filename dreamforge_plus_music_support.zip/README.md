# 🎵 DreamForge+ Music & Sound Support

This module adds music and sound support for the DreamForge+ app.

## 🎼 Features

- Upload your own music (`.mp3`, `.ogg`, `.wav`)
- Assign background music to scenes or maps
- Add sound effects to character actions or UI interactions
- Compatible with engines like Phaser, Godot, Unity, and more

## 📂 Folder Structure

Place your audio files here:

```
assets/
├── music/
│   ├── main_theme.mp3
│   └── level_intro.ogg
└── sfx/
    ├── jump.wav
    ├── pickup.wav
    └── win.mp3
```

## 💡 Usage

These files can be linked in the game builder UI or referenced by the AI assistant during game generation.

Example for Phaser:
```js
this.load.audio('main_theme', 'assets/music/main_theme.mp3');
this.load.audio('jump_sfx', 'assets/sfx/jump.wav');
```

## 📘 Tip

Music files should be optimized for mobile and web — shorter loops, lower bitrates, and seamless looping are best for performance.
