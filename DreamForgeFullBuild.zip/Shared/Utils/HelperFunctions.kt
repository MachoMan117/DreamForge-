// HelperFunctions.kt - Placeholder for Utils module

