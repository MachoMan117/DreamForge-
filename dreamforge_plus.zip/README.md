# DreamForge+ — Create, Learn, and Build Games with AI

DreamForge+ is a fully open-source, mobile-first game creation platform inspired by GB Studio and Replit — empowering anyone to create, code, and understand game development, no matter their experience level.

## 🎮 Game Maker Features (Like GB Studio)
- Drag-and-drop area/scene creation (coming soon)
- Character import and placement
- Entry/exit points with visual guides
- Asset upload and engine export (Phaser, Godot, Unity-ready)
- Text prompt-assisted scripting and event creation

## 💬 AI Assistant Features (Like Replit)
- GPT-powered code suggestions and game design help
- Explains unfamiliar code or errors
- Recommends engine-specific best practices
- Helps customize behavior and structure

## 📚 Learn Mode (Coming Soon)
- Beginner-friendly tutorials on Swift, Kotlin, JS, Lua, Python, and C#
- Lessons on how game engines work
- Interactive playground to practice live
- Game-specific coding tracks (e.g., “Platformers in Godot”)

## 🛠 Engine Integration Goals
- Phaser (HTML5)
- Godot (GDScript & C#)
- Unity (C#)
- Unreal Engine (Blueprint + C++)
- Love2D (Lua)

## 🗃️ Project Structure

```
dreamforge_plus/
├── android/              # Kotlin app
├── swift/                # iOS app
├── backend/              # Next.js + API routes
├── learn/                # Learn mode modules
├── engine-templates/     # GB Studio-style UI tools
├── assets/               # Art, icons, sample files
├── docs/                 # Architecture, dev guides
├── LICENSE               # MIT (see below)
├── README.md             # You're reading it
└── CONTRIBUTING.md       # How to help
```

## ⚖️ License (MIT + Community Clause)

This project is licensed under the permissive MIT license, and additionally includes a non-binding community request:

> This app is built to support the development of accessible, educational, and community-driven game tools. Please credit the original creators and help further the mission to make game development easier and more inclusive for future generations.

## 🙌 Contributors Wanted

- Game devs, artists, coders, teachers — welcome.
- Fork, remix, improve — just keep it free and open.
- Let’s build the future of creation together.

