# How to Contribute

Thanks for helping improve DreamForge+! Here's how to get started:

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Open a pull request
5. Join Discussions to propose features or fixes

You're helping build something that makes game development possible for everyone.
