# How to Contribute to DreamForge+

## Step 1: Join the Discord
Get your role and meet the team.

## Step 2: Choose Your Role
- DreamScribes: write tutorials, guides, UI copy
- DreamPainters: create assets and mockups
- DreamTuners: make music and sound effects
- DreamPlayers: test builds and give feedback

## Step 3: Submit Work
Upload to Discord or contribute via GitHub [link].

## Licensing
Everything you create is open source for DreamForge+ and the community to build on.
