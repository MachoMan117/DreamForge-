Welcome to the DreamForge+ Community!

This starter kit includes everything you need to start contributing as a:
- Forger (builder or learner)
- DreamPlayer (tester)
- DreamScribe (writer)
- DreamPainter (artist)
- DreamTuner (musician)

Visit our Discord to get your role and meet the team:
[Discord Invite Link]

Let’s build something beautiful together!
