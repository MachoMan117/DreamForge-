# 🎧 Getting Started with Game Music

## What You'll Learn
- What makes game music different
- How to loop a song cleanly
- Tools and formats used in game audio

## Tips
- Start with simple melodies that loop well
- Use `.ogg` or `.mp3` for music, `.wav` for short SFX
- Keep mobile performance in mind — small file sizes help

More tutorials coming soon!
