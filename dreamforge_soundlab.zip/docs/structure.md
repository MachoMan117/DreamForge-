# DreamForge SoundLab Structure

- `app/` — mobile UI for Android & iOS
- `samples/` — included loops and background tracks
- `tutorials/` — markdown-based lessons
- `ai-music/` — hooks for future integration (like Suno, Riffusion)

Open source and modular — contributions welcome!
